// ini warna

var warna = require('colors');

warna.setTheme({
  hijau : "green",
  biru : "blue",
  kuning : "yellow",
  merah : "red"
});
