# jadwal-sholat

cara install : 

$ pkg install git

$ pkg install nodejs

$ npm install --save request colors

$ git clone https://github.com/ibnusyawall/jadwal-sholat

$ cd jadwal-sholat

$ ls


## [ + ] Jadwal sholat per provinsi [ + ]
## [ ! ] Example : $ node Aceh ( enter ).
## [ ! ] Provinsi dengan kata panjang disingkat, example : $ node Sulsel     ( Sulawesi Selatan ).
## [ ? ] Edit bagian " waktu.json " di folder ' inc ' untuk mengatur tanggal per jadwal.
## [ ? ] Semua daerah ditulis dengan huruf kapital.

say alhamdulillah :)
